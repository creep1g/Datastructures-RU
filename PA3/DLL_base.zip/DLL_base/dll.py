
class Node:
    def __init__(self, data = None, prev = None, next = None):
        self.data = data
        self.prev = prev
        self.next = next

class DLL:
    def __init__(self):
        pass

    def insert(self, data):
        pass

    def remove(self):
        pass

    def get_value(self):
        return None

    def move_to_next(self):
        pass

    def move_to_prev(self):
        pass

    def move_to_pos(self, pos):
        pass

    def clear(self):
        pass

    def get_first_node(self):
        pass

    def get_last_node(self):
        pass

    def partition(self, low, high):
        pass

    def sort(self):
        pass

    def __len__(self):
        return 0

    def __str__(self):
        ret_str = ""
        return ret_str

if __name__ == "__main__":
    #create tests here if you want
    pass
    
