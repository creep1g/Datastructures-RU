
# IMPLEMENT HERE

if __name__ == "__main__":

    print("\nSHOWING HOW TO LOSE THE DELIMITERS, IF WANTED")
    statement_string = "OR(AND(T,F),F)"
    print(statement_string)
    # YOU CAN DO THIS IN YOUR build_tree() OPERATION IF THE LIST FORMAT FEELS BETTER
    statement_list = statement_string.replace("(", " ").replace(")", " ").replace(",", " ").split()
    print(statement_list)


    print("\n\nTESTING BOOLEAN TREE\n")

    # THESE TESTS SHOULD WORK EXACTLY AS THEY ARE BUT FEEL FREE TO MAKE MORE EXTENSIVE TESTS AS WELL

    bt = BooleanTree()
    statement_string = "OR(AND(T,F),F)"
    print(statement_string)
    bt.build_tree(statement_string)
    print(bt.get_root_value())
    statement_string = "OR(T,AND(T,F))"
    print(statement_string)
    bt.build_tree(statement_string)
    print(bt.get_root_value())
    statement_string = "OR(AND(T,T),F)"
    print(statement_string)
    bt.build_tree(statement_string)
    print(bt.get_root_value())
    statement_string = "AND(T,OR(F,F))"
    print(statement_string)
    bt.build_tree(statement_string)
    print(bt.get_root_value())
    statement_string = "AND(OR(F,T),T)"
    print(statement_string)
    bt.build_tree(statement_string)
    print(bt.get_root_value())
    statement_string = "AND(F,F)"
    print(statement_string)
    bt.build_tree(statement_string)
    print(bt.get_root_value())
    statement_string = "AND(OR(OR(F,F),T),OR(T,AND(T,F)))"
    print(statement_string)
    bt.build_tree(statement_string)
    print(bt.get_root_value())